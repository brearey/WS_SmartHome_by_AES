package ru.oktemsec.smarthome.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.JsonAdapter
import com.google.gson.annotations.SerializedName

class Item {
    @SerializedName("appId")
    @Expose
    var appId: String? = null

    @SerializedName("competitor")
    @Expose
    var competitor: String? = null
}