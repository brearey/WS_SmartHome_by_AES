package ru.oktemsec.smarthome.models

data class RequestRegisterApp(val appId:String, val competitor: String)