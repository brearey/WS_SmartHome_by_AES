package ru.oktemsec.smarthome

import android.animation.ObjectAnimator
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.core.animation.doOnEnd

class LaunchActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_launch)

        val animated_logo:ImageView = findViewById(R.id.animated_logo_iv)
        val animator = ObjectAnimator.ofFloat(animated_logo, "rotation", 360f).apply {
            duration = 1500
            start()
        }

        animator.doOnEnd {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

    }
}