package ru.oktemsec.smarthome

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import ru.oktemsec.smarthome.interfaces.Service
import ru.oktemsec.smarthome.models.Item
import ru.oktemsec.smarthome.models.Mobile
import java.util.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val COUNTRIES = arrayOf(
            "Belgium", "France", "Italy", "Germany", "Spain"
        )

        val myUUID = "02C2817E-7614-4A65-B323-E59890910234"

        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, COUNTRIES)
        val textView = findViewById<View>(R.id.ac_text) as AutoCompleteTextView
        textView.setAdapter(adapter)

        val resultTextView:TextView = findViewById(R.id.textView2)

        val search_button:Button = findViewById(R.id.search_button)
        search_button.setOnClickListener {
            getRegisteredDevicesList()
        }
        Log.d("brearey", BuildConfig.APPLICATION_ID)
    }

    private fun getAppId() {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://smarthome.madskill.ru/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val myService: Service = retrofit.create(Service::class.java)
        val call: Call<Array<Item>> = myService.getRegisteredAppsList("Competitor-8")

        call.enqueue(object : Callback<Array<Item>?> {
            override fun onResponse(call: Call<Array<Item>?>, response: Response<Array<Item>?>) {
                Log.i("Responsestring", response.body().toString())
                //Toast.makeText()
                if (response.isSuccessful) {
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString())
                        Log.d("brearey", response.body()!![2].appId.toString())
                    } else {
                        Log.i(
                            "onEmptyResponse",
                            "Returned empty response"
                        ) //Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }
            }

            override fun onFailure(call: Call<Array<Item>?>, t: Throwable) {
                Log.e("brearey", "Failed", t)
            }
        })
    }

    //Registration app
    private fun registerApp() {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://smarthome.madskill.ru/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val myService: Service = retrofit.create(Service::class.java)
        val call: Call<String> = myService.registerApp(ru.oktemsec.smarthome.models.RequestRegisterApp(BuildConfig.APPLICATION_ID, "Competitor-8"))

        call.enqueue(object : Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                Log.i("Responsestring", response.body().toString())
                Log.i("ResponseCode", response.code().toString())
                //Toast.makeText()
                if (response.isSuccessful) {
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString())
                        Log.d("brearey", response.body().toString())
                    } else {
                        Log.i(
                            "onEmptyResponse",
                            "Returned empty response"
                        ) //Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }
            }

            override fun onFailure(call: Call<String>, t: Throwable) {
                Log.e("brearey", "Failed", t)
            }
        })
    }

    //Registration mobile
    private fun registerMobile() {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://smarthome.madskill.ru/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val myService: Service = retrofit.create(Service::class.java)
        val call: Call<KeyDevice> = myService.registerMobile(RequestRegisterMobile(UUID.randomUUID().toString(), BuildConfig.APPLICATION_ID, Build.DEVICE))

        call.enqueue(object : Callback<KeyDevice> {
            override fun onResponse(call: Call<KeyDevice>, response: Response<KeyDevice>) {
                Log.i("Responsestring", response.body().toString())
                Log.i("ResponseCode", response.code().toString())
                //Toast.makeText()
                if (response.isSuccessful) {
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString())
                        Log.d("brearey", response.body()!!.keyDevice)

                        val keyDevice = response.body()!!.keyDevice
                    } else {
                        Log.i(
                            "onEmptyResponse",
                            "Returned empty response"
                        ) //Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }
            }

            override fun onFailure(call: Call<KeyDevice>, t: Throwable) {
                Log.e("brearey", "Failed", t)
            }
        })
    }

    private fun getRegisteredDevicesList() {
        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl("https://smarthome.madskill.ru/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val myService: Service = retrofit.create(Service::class.java)
        val call: Call<Array<Mobile>> = myService.getRegisteredDevicesList(BuildConfig.APPLICATION_ID)

        call.enqueue(object : Callback<Array<Mobile>?> {
            override fun onResponse(call: Call<Array<Mobile>?>, response: Response<Array<Mobile>?>) {
                Log.i("Responsestring", response.body().toString())
                //Toast.makeText()
                if (response.isSuccessful) {
                    if (response.body() != null) {
                        Log.i("onSuccess", response.body().toString())
                        Log.d("brearey", response.body()!![2].device.toString())
                    } else {
                        Log.i(
                            "onEmptyResponse",
                            "Returned empty response"
                        ) //Toast.makeText(getContext(),"Nothing returned",Toast.LENGTH_LONG).show();
                    }
                }
            }

            override fun onFailure(call: Call<Array<Mobile>?>, t: Throwable) {
                Log.e("brearey", "Failed", t)
            }
        })
    }
}

class RequestRegisterMobile(val uuid:String, val appId: String, val device: String)

class KeyDevice(val keyDevice: String)