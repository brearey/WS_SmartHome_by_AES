package ru.oktemsec.smarthome.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class Result {
    var array:Array<Item>? = null

}