package ru.oktemsec.smarthome.interfaces

import retrofit2.Call
import retrofit2.http.*
import ru.oktemsec.smarthome.KeyDevice
import ru.oktemsec.smarthome.RequestRegisterMobile
import ru.oktemsec.smarthome.models.Item
import ru.oktemsec.smarthome.models.Mobile
import ru.oktemsec.smarthome.models.RequestRegisterApp


interface Service {
    @GET("/app")
    fun getRegisteredAppsList(@Query("competitor") competitor:String = "Competitor-8"): Call<Array<Item>>

    @POST("/app")
    fun registerApp(@Body body: RequestRegisterApp): Call<String>

    @POST("/mobile")
    fun registerMobile(@Body body: RequestRegisterMobile): Call<KeyDevice>

    @GET("/mobile")
    fun getRegisteredDevicesList(@Query("appId") appId:String): Call<Array<Mobile>>
}