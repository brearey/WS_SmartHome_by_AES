package ru.oktemsec.smarthome.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Mobile {
    @SerializedName("uuid")
    @Expose
    var uuid: String? = null

    @SerializedName("apId")
    @Expose
    var appId: String? = null

    @SerializedName("device")
    @Expose
    var device: String? = null
}

/*
{
  "uuid": "5FA1B987-3890-4A87-9712-ACDEAD0173AE",
  "appId": "com.example.myapplication",
  "device": "iPhone SE (2nd generation)"
}
 */